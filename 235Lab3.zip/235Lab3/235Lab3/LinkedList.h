#ifndef LINKED_LIST_H
#define LINKED_LIST_H
#include"Linked List Interface.h"
#include<ostream>
#include<sstream>
using namespace std;

template <typename T>
class LinkedList : public LinkedListInterface<T> {
public:
	T data;
	LinkedList* next;


	LinkedList(T data) : data(data), next(NULL) {}
	LinkedList(T data, LinkedList* next) : data(data), next(next) {}
	LinkedList() : data(NULL), next(NULL) {}




	void push_front(const T& value) {
		//cout << "Our data is " << data << " Our next is" << next;
		
		
		next = new LinkedList<T>(data, next);
		data = value;	

	}

	string toString(void) const {
		ostringstream output;
		LinkedList<T> * tempPtr = this->next;

		output << data << " ";

		while (tempPtr != NULL) {
			output << tempPtr->data;
			if (tempPtr->next != NULL) {
				output << " ";
			}
			tempPtr = tempPtr->next;
		}		

		return output.str();
	}

	void pop_front(void) {
		
		T toStoreInData = next->data;
		LinkedList<T> * theNextPointer = next->next;

		data = toStoreInData;
		next = theNextPointer;

		//cout << "we're doing it";
		//delete next;
	}
	void clear(void) {
		LinkedList<T> * theNextNode = next;
		while (next != NULL) {
			LinkedList<T> * theNextNode = next;

			delete this;
		}

	}

	T& front(void) {
		return data;
	}

	void remove(const T& value) {
		while (next != NULL) {
			if (next->data == value) {
				next = next->next;
				//FIXME DELETE NEXT VALUE
			}

		}

	}

	//questions:  How do I test if linked list is empty if my head is a pointer to a null
	//how to get head to point to a null with the clear function
	//



};




#endif // !LINKED_LIST_H
